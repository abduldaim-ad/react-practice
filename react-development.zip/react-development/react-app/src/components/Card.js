import React from 'react'
import './Card.css'

const Card = (props) => {

    const {image, title, desc} = props

  return (
    <>
    <div className='main-div'>
        <section>
            <img className='image-img' src={image}/>
        </section>

        <section className='sub-section'>
            <h3 className='title-h3'>{title}</h3>
            <p className='desc-p'>{desc}</p>
        </section>
    </div>
    </>
  )
}

export default Card