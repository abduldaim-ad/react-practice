import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <>
       <h1 className='main-heading'>Air University</h1>
       <h3 className='sub-heading'>Taking Academic Excellence to New Heights</h3>
    </>
  )
}

export default Header